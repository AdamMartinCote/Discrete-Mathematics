#include "UsineLexique.h"

#include <iostream>
#include <vector>



UsineLexique::UsineLexique()
{
}


UsineLexique::~UsineLexique()
{
}

std::unique_ptr<Lexique> UsineLexique::initialiserLexique(std::string nomFichier)
{
	std::ifstream fichier;
	fichier.open(nomFichier);
	if (!fichier.is_open()) throw std::runtime_error("Le fichier n'a pu �tre ouvert, v�rifier le chemin d'acc�s.");

	// creer un arbre de toute les sous-chaines, sans optimisation (avec doublons)
	std::string buffer, sousChaine;
	std::unique_ptr<Lexique> lexique(new Lexique());
	while (std::getline(fichier, buffer)) {

		auto nouveauNoeud = std::make_shared<Noeud>(buffer.substr(0, 1), false, 1);	//premiere lettre
		auto dernierNoeud = nouveauNoeud;
		lexique->lettresArbres_.push_back(nouveauNoeud);

		unsigned int longueurSousChaine = 2;
		while (longueurSousChaine <= buffer.length()) {	// generer les sous-chaines et les chainer
			sousChaine = buffer.substr(0, longueurSousChaine);
			nouveauNoeud = std::make_shared<Noeud>(sousChaine, false, longueurSousChaine);
			dernierNoeud->ajouterEnfant(nouveauNoeud);
			dernierNoeud = nouveauNoeud;
			longueurSousChaine++;
		}
	}
	return lexique;
}

std::unique_ptr<Lexique> UsineLexique::initialiserLexiqueOptimise1(std::string nomFichier)
{
	std::ifstream fichier;
	fichier.open(nomFichier);
	if (!fichier.is_open()) throw std::runtime_error("Le fichier n'a pu �tre ouvert, v�rifier le chemin d'acc�s.");

	// cree un arbre unique pour chaque lettre
	std::string buffer, sousChaine;
	std::unique_ptr<Lexique> lexique(new Lexique());
	while (std::getline(fichier, buffer)) {

		auto nouveauNoeud = std::make_shared<Noeud>(buffer.substr(0, 1), false, 1);	//premiere lettre
		auto dernierNoeud = nouveauNoeud;

		std::vector<std::shared_ptr<Noeud>>::iterator it = lexique->lettresArbres_.begin();
		while (
			it != lexique->lettresArbres_.end() && 
			(*it)->obtenirValeur() != nouveauNoeud->obtenirValeur()) 
		{
			it++;
		}
		if (it == lexique->lettresArbres_.end()) {
			lexique->lettresArbres_.push_back(nouveauNoeud);
		}
		else {
			dernierNoeud = *it;
		}
		unsigned int longueurSousChaine = 2;
		while (longueurSousChaine <= buffer.length()) {	// generer les sous-chaines et les chainer
			sousChaine = buffer.substr(0, longueurSousChaine);
			nouveauNoeud = std::make_shared<Noeud>(sousChaine, false, longueurSousChaine);
			dernierNoeud->ajouterEnfant(nouveauNoeud);
			dernierNoeud = nouveauNoeud;
			longueurSousChaine++;
		}
		dernierNoeud->marquerUnMot();
	}
	return lexique;
}

std::unique_ptr<Lexique> UsineLexique::initialiserLexiqueOptimise2(std::string nomFichier)
{
	std::ifstream fichier;
	fichier.open(nomFichier);
	if (!fichier.is_open()) throw std::runtime_error("Le fichier n'a pu �tre ouvert, v�rifier le chemin d'acc�s.");

	// cree un arbre optimis� pour chaque lettre, si 2 mots contiennent la sous-chaine "acceuill" par exemple
	// il y a un seul noeud pour cette valeur
	std::string buffer, sousChaine;
	std::unique_ptr<Lexique> lexique(new Lexique());
	while (std::getline(fichier, buffer)) {

		auto nouveauNoeud = std::make_shared<Noeud>(buffer.substr(0, 1), false, 1);	//premiere lettre
		std::shared_ptr<Noeud> dernierNoeud = nouveauNoeud;

		std::vector<std::shared_ptr<Noeud> >::iterator it = lexique->lettresArbres_.begin();
		while (
			it != lexique->lettresArbres_.end() &&
			(*it)->obtenirValeur() != nouveauNoeud->obtenirValeur())
		{
			it++;
		}
		if (it == lexique->lettresArbres_.end()) {
			lexique->lettresArbres_.push_back(nouveauNoeud);
		}
		else {
			dernierNoeud = *it;
		}
		unsigned int longueurSousChaine = 2;
		while (longueurSousChaine <= buffer.length()) {	// generer les sous-chaines et les chainer

			sousChaine = buffer.substr(0, longueurSousChaine);
			for (unsigned int i = 0; i < dernierNoeud->obtenirEnfants().size(); i++) {
				if (dernierNoeud.get()->obtenirEnfants().at(i).get()->obtenirValeur() == sousChaine) {
					dernierNoeud = dernierNoeud->obtenirEnfants().at(i);
				}
			}
			if (dernierNoeud->obtenirValeur() != sousChaine) {
				nouveauNoeud = std::make_shared<Noeud>(sousChaine, false, longueurSousChaine);
				dernierNoeud->ajouterEnfant(nouveauNoeud);
				dernierNoeud = nouveauNoeud;
			}
			longueurSousChaine++;
		}
		dernierNoeud->marquerUnMot();
	}
	return lexique;
}